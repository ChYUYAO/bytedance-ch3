package com.example.myanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
//import android.view.animation.AlphaAnimation;
//import android.view.animation.ScaleAnimation;
//import android.view.animation.AnimationSet;
import android.widget.ImageView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button mAlphaBtn;
    private Button mScaleBtn;
    private Button mAnimationSet;
    private ImageView mImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);
        mAlphaBtn = findViewById(R.id.btn_alpha);
        mScaleBtn = findViewById(R.id.btn_scale);
        mAnimationSet = findViewById(R.id.btn_animation_set);
        mImage = findViewById(R.id.btn_image);
        mAlphaBtn.setOnClickListener(this);
        mScaleBtn.setOnClickListener(this);
        mAnimationSet.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Animation loadAnimation;
        switch (v.getId()) {
            case R.id.btn_scale:
                loadAnimation = AnimationUtils.loadAnimation(this, R.anim.scale);
                mImage.startAnimation(loadAnimation);
                break;
            case R.id.btn_alpha:
                loadAnimation = AnimationUtils.loadAnimation(this, R.anim.alpha);
                mImage.startAnimation(loadAnimation);
                break;
            case R.id.btn_animation_set:
                //AlphaAnimation alphaAnimation = new AlphaAnimation(1,0);
                //ScaleAnimation scaleAnimation = new ScaleAnimation(1,2,1,2);
                //AnimationSet animationSet = new AnimationSet (true);
                //animationSet.addAnimation( alphaAnimation);
                //animationSet.addAnimation( scaleAnimation);
                //mImage.startAnimation(animationSet);
                loadAnimation = AnimationUtils.loadAnimation(this, R.anim.continue_anim);
                mImage.startAnimation(loadAnimation);
                break;
            default:
                break;
        }
    }
}
